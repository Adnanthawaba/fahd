from flask import Blueprint, jsonify, request
from werkzeug.security import generate_password_hash, check_password_hash
from src.models.user import User, UserRole, db
from datetime import datetime
import re

auth_bp = Blueprint('auth', __name__)

def validate_email(email):
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None

def validate_phone(phone):
    # Yemen phone number validation (starts with +967 or 967 or local format)
    pattern = r'^(\+967|967|0)?[1-9]\d{7,8}$'
    return re.match(pattern, phone) is not None

@auth_bp.route('/register', methods=['POST'])
def register():
    try:
        data = request.json
        
        # Validate required fields
        required_fields = ['first_name_en', 'last_name_en', 'email', 'phone_number', 'password']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        # Validate email format
        if not validate_email(data['email']):
            return jsonify({'error': 'Invalid email format'}), 400
        
        # Validate phone number
        if not validate_phone(data['phone_number']):
            return jsonify({'error': 'Invalid Yemen phone number format'}), 400
        
        # Check if user already exists
        if User.query.filter_by(email=data['email']).first():
            return jsonify({'error': 'Email already registered'}), 400
        
        if User.query.filter_by(phone_number=data['phone_number']).first():
            return jsonify({'error': 'Phone number already registered'}), 400
        
        # Determine user role
        role = UserRole.VENUE_OWNER if data.get('is_venue_owner') else UserRole.CUSTOMER
        
        # Create new user
        user = User(
            first_name_en=data['first_name_en'],
            first_name_ar=data.get('first_name_ar'),
            last_name_en=data['last_name_en'],
            last_name_ar=data.get('last_name_ar'),
            email=data['email'].lower(),
            phone_number=data['phone_number'],
            whatsapp_number=data.get('whatsapp_number'),
            password_hash=generate_password_hash(data['password']),
            role=role,
            preferred_language=data.get('preferred_language', 'ar'),
            city_en=data.get('city_en'),
            city_ar=data.get('city_ar'),
            governorate_en=data.get('governorate_en'),
            governorate_ar=data.get('governorate_ar'),
            business_name_en=data.get('business_name_en') if role == UserRole.VENUE_OWNER else None,
            business_name_ar=data.get('business_name_ar') if role == UserRole.VENUE_OWNER else None,
            business_license=data.get('business_license') if role == UserRole.VENUE_OWNER else None,
            business_address_en=data.get('business_address_en') if role == UserRole.VENUE_OWNER else None,
            business_address_ar=data.get('business_address_ar') if role == UserRole.VENUE_OWNER else None
        )
        
        db.session.add(user)
        db.session.commit()
        
        language = data.get('preferred_language', 'ar')
        return jsonify({
            'message': 'User registered successfully',
            'user': user.to_dict(language=language)
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@auth_bp.route('/login', methods=['POST'])
def login():
    try:
        data = request.json
        
        if not data.get('email') or not data.get('password'):
            return jsonify({'error': 'Email and password are required'}), 400
        
        user = User.query.filter_by(email=data['email'].lower()).first()
        
        if not user or not check_password_hash(user.password_hash, data['password']):
            return jsonify({'error': 'Invalid email or password'}), 401
        
        if not user.is_active:
            return jsonify({'error': 'Account is deactivated'}), 401
        
        # Update last login
        user.last_login = datetime.utcnow()
        db.session.commit()
        
        language = data.get('language', user.preferred_language)
        return jsonify({
            'message': 'Login successful',
            'user': user.to_dict(language=language)
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@auth_bp.route('/verify-phone', methods=['POST'])
def verify_phone():
    try:
        data = request.json
        user_id = data.get('user_id')
        verification_code = data.get('verification_code')
        
        if not user_id or not verification_code:
            return jsonify({'error': 'User ID and verification code are required'}), 400
        
        user = User.query.get(user_id)
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        # In a real implementation, you would verify the SMS code here
        # For demo purposes, we'll accept any 4-digit code
        if len(verification_code) == 4 and verification_code.isdigit():
            user.is_phone_verified = True
            db.session.commit()
            
            return jsonify({
                'message': 'Phone number verified successfully',
                'user': user.to_dict()
            }), 200
        else:
            return jsonify({'error': 'Invalid verification code'}), 400
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@auth_bp.route('/forgot-password', methods=['POST'])
def forgot_password():
    try:
        data = request.json
        email = data.get('email')
        
        if not email:
            return jsonify({'error': 'Email is required'}), 400
        
        user = User.query.filter_by(email=email.lower()).first()
        if not user:
            # Don't reveal if email exists or not for security
            return jsonify({'message': 'If the email exists, a reset link has been sent'}), 200
        
        # In a real implementation, you would send a password reset email here
        # For demo purposes, we'll just return success
        return jsonify({'message': 'Password reset link sent to your email'}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@auth_bp.route('/change-password', methods=['POST'])
def change_password():
    try:
        data = request.json
        user_id = data.get('user_id')
        current_password = data.get('current_password')
        new_password = data.get('new_password')
        
        if not all([user_id, current_password, new_password]):
            return jsonify({'error': 'All fields are required'}), 400
        
        user = User.query.get(user_id)
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        if not check_password_hash(user.password_hash, current_password):
            return jsonify({'error': 'Current password is incorrect'}), 400
        
        if len(new_password) < 6:
            return jsonify({'error': 'New password must be at least 6 characters'}), 400
        
        user.password_hash = generate_password_hash(new_password)
        db.session.commit()
        
        return jsonify({'message': 'Password changed successfully'}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@auth_bp.route('/governorates', methods=['GET'])
def get_governorates():
    """Get list of Yemen governorates"""
    governorates = [
        {'name_en': 'Sana\'a', 'name_ar': 'صنعاء'},
        {'name_en': 'Aden', 'name_ar': 'عدن'},
        {'name_en': 'Taiz', 'name_ar': 'تعز'},
        {'name_en': 'Hodeidah', 'name_ar': 'الحديدة'},
        {'name_en': 'Ibb', 'name_ar': 'إب'},
        {'name_en': 'Dhamar', 'name_ar': 'ذمار'},
        {'name_en': 'Mukalla', 'name_ar': 'المكلا'},
        {'name_en': 'Hajjah', 'name_ar': 'حجة'},
        {'name_en': 'Amran', 'name_ar': 'عمران'},
        {'name_en': 'Sa\'ada', 'name_ar': 'صعدة'},
        {'name_en': 'Lahij', 'name_ar': 'لحج'},
        {'name_en': 'Abyan', 'name_ar': 'أبين'},
        {'name_en': 'Shabwah', 'name_ar': 'شبوة'},
        {'name_en': 'Marib', 'name_ar': 'مأرب'},
        {'name_en': 'Al Jawf', 'name_ar': 'الجوف'},
        {'name_en': 'Al Bayda', 'name_ar': 'البيضاء'},
        {'name_en': 'Al Dhale', 'name_ar': 'الضالع'},
        {'name_en': 'Raymah', 'name_ar': 'ريمة'},
        {'name_en': 'Al Mahwit', 'name_ar': 'المحويت'},
        {'name_en': 'Hadramout', 'name_ar': 'حضرموت'},
        {'name_en': 'Al Mahrah', 'name_ar': 'المهرة'},
        {'name_en': 'Socotra', 'name_ar': 'سقطرى'}
    ]
    
    language = request.args.get('language', 'ar')
    if language == 'en':
        return jsonify([{'name': gov['name_en'], 'name_ar': gov['name_ar']} for gov in governorates])
    else:
        return jsonify([{'name': gov['name_ar'], 'name_en': gov['name_en']} for gov in governorates])

