from flask_sqlalchemy import SQLAlchemy
from src.models.user import db
from datetime import datetime
from enum import Enum

class MessageType(Enum):
    TEXT = "text"
    IMAGE = "image"
    VOICE = "voice"
    DOCUMENT = "document"

class MessageStatus(Enum):
    SENT = "sent"
    DELIVERED = "delivered"
    READ = "read"

class Message(db.Model):
    __tablename__ = 'messages'
    
    id = db.Column(db.Integer, primary_key=True)
    
    # Relationships
    sender_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    receiver_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    booking_id = db.Column(db.Integer, db.ForeignKey('bookings.id'))  # Optional: link to booking
    
    # Message content
    message_type = db.Column(db.Enum(MessageType), default=MessageType.TEXT)
    content = db.Column(db.Text)
    file_url = db.Column(db.String(500))  # For images, voice, documents
    file_name = db.Column(db.String(200))
    file_size = db.Column(db.Integer)
    
    # Message status
    status = db.Column(db.Enum(MessageStatus), default=MessageStatus.SENT)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    delivered_at = db.Column(db.DateTime)
    read_at = db.Column(db.DateTime)
    
    # Relationships
    sender = db.relationship('User', foreign_keys=[sender_id], backref='sent_messages')
    receiver = db.relationship('User', foreign_keys=[receiver_id], backref='received_messages')
    
    def __repr__(self):
        return f'<Message {self.id} from {self.sender_id} to {self.receiver_id}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'sender_id': self.sender_id,
            'receiver_id': self.receiver_id,
            'booking_id': self.booking_id,
            'message_type': self.message_type.value if self.message_type else None,
            'content': self.content,
            'file_url': self.file_url,
            'file_name': self.file_name,
            'file_size': self.file_size,
            'status': self.status.value if self.status else None,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'delivered_at': self.delivered_at.isoformat() if self.delivered_at else None,
            'read_at': self.read_at.isoformat() if self.read_at else None
        }

class Review(db.Model):
    __tablename__ = 'reviews'
    
    id = db.Column(db.Integer, primary_key=True)
    
    # Relationships
    customer_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    venue_id = db.Column(db.Integer, db.ForeignKey('venues.id'), nullable=False)
    booking_id = db.Column(db.Integer, db.ForeignKey('bookings.id'))
    
    # Review content
    rating = db.Column(db.Integer, nullable=False)  # 1-5 stars
    title_en = db.Column(db.String(200))
    title_ar = db.Column(db.String(200))
    comment_en = db.Column(db.Text)
    comment_ar = db.Column(db.Text)
    
    # Review status
    is_approved = db.Column(db.Boolean, default=True)
    is_featured = db.Column(db.Boolean, default=False)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    customer = db.relationship('User', backref='reviews')
    
    def __repr__(self):
        return f'<Review {self.id} - {self.rating} stars>'
    
    def to_dict(self, language='en'):
        title = self.title_en if language == 'en' else self.title_ar
        comment = self.comment_en if language == 'en' else self.comment_ar
        
        return {
            'id': self.id,
            'customer_id': self.customer_id,
            'venue_id': self.venue_id,
            'booking_id': self.booking_id,
            'rating': self.rating,
            'title': title,
            'comment': comment,
            'is_approved': self.is_approved,
            'is_featured': self.is_featured,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

