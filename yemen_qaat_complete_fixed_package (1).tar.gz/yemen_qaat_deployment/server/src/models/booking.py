from flask_sqlalchemy import SQLAlchemy
from src.models.user import db
from datetime import datetime
from enum import Enum

class BookingStatus(Enum):
    PENDING = "pending"
    CONFIRMED = "confirmed"
    CANCELLED = "cancelled"
    COMPLETED = "completed"

class PaymentStatus(Enum):
    PENDING = "pending"
    PARTIAL = "partial"
    PAID = "paid"
    REFUNDED = "refunded"

class PaymentMethod(Enum):
    CASH = "cash"
    BANK_TRANSFER = "bank_transfer"
    MOBILE_PAYMENT = "mobile_payment"
    YEMEN_PAYMENT = "yemen_payment"
    CASH_EWALLET = "cash_ewallet"
    KURAIMI_JAWAL = "kuraimi_jawal"

class Booking(db.Model):
    __tablename__ = 'bookings'
    
    id = db.Column(db.Integer, primary_key=True)
    booking_reference = db.Column(db.String(20), unique=True, nullable=False)
    
    # Relationships
    customer_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    venue_id = db.Column(db.Integer, db.ForeignKey('venues.id'), nullable=False)
    event_type_id = db.Column(db.Integer, db.ForeignKey('event_types.id'), nullable=False)
    
    # Event details
    event_date = db.Column(db.Date, nullable=False)
    start_time = db.Column(db.Time, nullable=False)
    end_time = db.Column(db.Time, nullable=False)
    guest_count = db.Column(db.Integer, nullable=False)
    
    # Event description
    event_title_en = db.Column(db.String(200))
    event_title_ar = db.Column(db.String(200))
    special_requirements_en = db.Column(db.Text)
    special_requirements_ar = db.Column(db.Text)
    
    # Pricing
    base_price = db.Column(db.Float, nullable=False)
    additional_charges = db.Column(db.Float, default=0.0)
    discount = db.Column(db.Float, default=0.0)
    total_amount = db.Column(db.Float, nullable=False)
    
    # Status
    booking_status = db.Column(db.Enum(BookingStatus), default=BookingStatus.PENDING)
    payment_status = db.Column(db.Enum(PaymentStatus), default=PaymentStatus.PENDING)
    payment_method = db.Column(db.Enum(PaymentMethod))
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    confirmed_at = db.Column(db.DateTime)
    cancelled_at = db.Column(db.DateTime)
    
    # Cancellation details
    cancellation_reason_en = db.Column(db.Text)
    cancellation_reason_ar = db.Column(db.Text)
    cancelled_by_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    
    # Relationships
    customer = db.relationship('User', foreign_keys=[customer_id], backref='customer_bookings')
    cancelled_by = db.relationship('User', foreign_keys=[cancelled_by_id])
    event_type = db.relationship('EventType', backref='bookings')
    payments = db.relationship('Payment', backref='booking', lazy=True)
    messages = db.relationship('Message', backref='booking', lazy=True)
    
    def __repr__(self):
        return f'<Booking {self.booking_reference}>'
    
    def to_dict(self, language='en'):
        event_title = self.event_title_en if language == 'en' else self.event_title_ar
        special_requirements = self.special_requirements_en if language == 'en' else self.special_requirements_ar
        cancellation_reason = self.cancellation_reason_en if language == 'en' else self.cancellation_reason_ar
        
        return {
            'id': self.id,
            'booking_reference': self.booking_reference,
            'customer_id': self.customer_id,
            'venue_id': self.venue_id,
            'event_type_id': self.event_type_id,
            'event_date': self.event_date.isoformat() if self.event_date else None,
            'start_time': self.start_time.strftime('%H:%M') if self.start_time else None,
            'end_time': self.end_time.strftime('%H:%M') if self.end_time else None,
            'guest_count': self.guest_count,
            'event_title': event_title,
            'special_requirements': special_requirements,
            'base_price': self.base_price,
            'additional_charges': self.additional_charges,
            'discount': self.discount,
            'total_amount': self.total_amount,
            'booking_status': self.booking_status.value if self.booking_status else None,
            'payment_status': self.payment_status.value if self.payment_status else None,
            'payment_method': self.payment_method.value if self.payment_method else None,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'confirmed_at': self.confirmed_at.isoformat() if self.confirmed_at else None,
            'cancelled_at': self.cancelled_at.isoformat() if self.cancelled_at else None,
            'cancellation_reason': cancellation_reason,
            'cancelled_by_id': self.cancelled_by_id
        }

class Payment(db.Model):
    __tablename__ = 'payments'
    
    id = db.Column(db.Integer, primary_key=True)
    booking_id = db.Column(db.Integer, db.ForeignKey('bookings.id'), nullable=False)
    payment_reference = db.Column(db.String(50), unique=True)
    
    amount = db.Column(db.Float, nullable=False)
    payment_method = db.Column(db.Enum(PaymentMethod), nullable=False)
    payment_status = db.Column(db.Enum(PaymentStatus), default=PaymentStatus.PENDING)
    
    # Payment details
    transaction_id = db.Column(db.String(100))
    payment_gateway_response = db.Column(db.JSON)
    
    # Bank transfer details
    bank_name = db.Column(db.String(100))
    account_number = db.Column(db.String(50))
    transfer_receipt_url = db.Column(db.String(500))
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    paid_at = db.Column(db.DateTime)
    
    def to_dict(self):
        return {
            'id': self.id,
            'booking_id': self.booking_id,
            'payment_reference': self.payment_reference,
            'amount': self.amount,
            'payment_method': self.payment_method.value if self.payment_method else None,
            'payment_status': self.payment_status.value if self.payment_status else None,
            'transaction_id': self.transaction_id,
            'bank_name': self.bank_name,
            'account_number': self.account_number,
            'transfer_receipt_url': self.transfer_receipt_url,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'paid_at': self.paid_at.isoformat() if self.paid_at else None
        }

