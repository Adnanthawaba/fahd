from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, date
from enum import Enum

db = SQLAlchemy()

class AvailabilityStatus(Enum):
    AVAILABLE = "available"
    BOOKED = "booked"
    PARTIALLY_AVAILABLE = "partially_available"
    MAINTENANCE = "maintenance"
    BLOCKED = "blocked"

class VenueAvailability(db.Model):
    __tablename__ = 'venue_availability'
    
    id = db.Column(db.Integer, primary_key=True)
    venue_id = db.Column(db.Integer, db.ForeignKey('venues.id'), nullable=False)
    date = db.Column(db.Date, nullable=False)
    start_time = db.Column(db.Time, nullable=False)
    end_time = db.Column(db.Time, nullable=False)
    status = db.Column(db.Enum(AvailabilityStatus), nullable=False, default=AvailabilityStatus.AVAILABLE)
    booking_id = db.Column(db.Integer, db.ForeignKey('bookings.id'), nullable=True)
    price_per_hour = db.Column(db.Float, nullable=True)
    notes = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    venue = db.relationship('Venue', backref='availability_slots')
    booking = db.relationship('Booking', backref='availability_slot')
    
    def to_dict(self):
        return {
            'id': self.id,
            'venue_id': self.venue_id,
            'date': self.date.isoformat() if self.date else None,
            'start_time': self.start_time.strftime('%H:%M') if self.start_time else None,
            'end_time': self.end_time.strftime('%H:%M') if self.end_time else None,
            'status': self.status.value if self.status else None,
            'booking_id': self.booking_id,
            'price_per_hour': self.price_per_hour,
            'notes': self.notes,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class VenueBlockedDates(db.Model):
    __tablename__ = 'venue_blocked_dates'
    
    id = db.Column(db.Integer, primary_key=True)
    venue_id = db.Column(db.Integer, db.ForeignKey('venues.id'), nullable=False)
    start_date = db.Column(db.Date, nullable=False)
    end_date = db.Column(db.Date, nullable=False)
    reason = db.Column(db.String(255), nullable=True)
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    venue = db.relationship('Venue', backref='blocked_dates')
    creator = db.relationship('User', backref='blocked_dates_created')
    
    def to_dict(self):
        return {
            'id': self.id,
            'venue_id': self.venue_id,
            'start_date': self.start_date.isoformat() if self.start_date else None,
            'end_date': self.end_date.isoformat() if self.end_date else None,
            'reason': self.reason,
            'created_by': self.created_by,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class VenueOperatingHours(db.Model):
    __tablename__ = 'venue_operating_hours'
    
    id = db.Column(db.Integer, primary_key=True)
    venue_id = db.Column(db.Integer, db.ForeignKey('venues.id'), nullable=False)
    day_of_week = db.Column(db.Integer, nullable=False)  # 0=Monday, 6=Sunday
    open_time = db.Column(db.Time, nullable=False)
    close_time = db.Column(db.Time, nullable=False)
    is_closed = db.Column(db.Boolean, default=False)
    
    # Relationships
    venue = db.relationship('Venue', backref='operating_hours')
    
    def to_dict(self):
        return {
            'id': self.id,
            'venue_id': self.venue_id,
            'day_of_week': self.day_of_week,
            'open_time': self.open_time.strftime('%H:%M') if self.open_time else None,
            'close_time': self.close_time.strftime('%H:%M') if self.close_time else None,
            'is_closed': self.is_closed
        }

