from flask_sqlalchemy import SQLAlchemy
from src.models.user import db
from datetime import datetime

class Venue(db.Model):
    __tablename__ = 'venues'
    
    id = db.Column(db.Integer, primary_key=True)
    name_en = db.Column(db.String(200), nullable=False)
    name_ar = db.Column(db.String(200), nullable=False)
    description_en = db.Column(db.Text)
    description_ar = db.Column(db.Text)
    
    # Owner information
    owner_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    # Location details
    address_en = db.Column(db.String(500), nullable=False)
    address_ar = db.Column(db.String(500), nullable=False)
    city_en = db.Column(db.String(100), nullable=False)
    city_ar = db.Column(db.String(100), nullable=False)
    governorate_en = db.Column(db.String(100), nullable=False)
    governorate_ar = db.Column(db.String(100), nullable=False)
    latitude = db.Column(db.Float)
    longitude = db.Column(db.Float)
    
    # Venue details
    capacity = db.Column(db.Integer, nullable=False)
    area_sqm = db.Column(db.Float)
    price_per_hour = db.Column(db.Float)
    price_per_day = db.Column(db.Float)
    
    # Amenities (stored as JSON)
    amenities = db.Column(db.JSON)
    
    # Contact information
    phone_primary = db.Column(db.String(20))
    phone_secondary = db.Column(db.String(20))
    whatsapp_number = db.Column(db.String(20))
    email = db.Column(db.String(120))
    
    # Status and verification
    is_active = db.Column(db.Boolean, default=True)
    is_verified = db.Column(db.Boolean, default=False)
    verification_date = db.Column(db.DateTime)
    
    # Ratings and reviews
    average_rating = db.Column(db.Float, default=0.0)
    total_reviews = db.Column(db.Integer, default=0)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    owner = db.relationship('User', backref='venues')
    bookings = db.relationship('Booking', backref='venue', lazy=True)
    images = db.relationship('VenueImage', backref='venue', lazy=True)
    reviews = db.relationship('Review', backref='venue', lazy=True)
    
    def __repr__(self):
        return f'<Venue {self.name_en}>'
    
    def to_dict(self, language='en'):
        """Convert venue to dictionary with language support"""
        name = self.name_en if language == 'en' else self.name_ar
        description = self.description_en if language == 'en' else self.description_ar
        address = self.address_en if language == 'en' else self.address_ar
        city = self.city_en if language == 'en' else self.city_ar
        governorate = self.governorate_en if language == 'en' else self.governorate_ar
        
        return {
            'id': self.id,
            'name': name,
            'description': description,
            'address': address,
            'city': city,
            'governorate': governorate,
            'latitude': self.latitude,
            'longitude': self.longitude,
            'capacity': self.capacity,
            'area_sqm': self.area_sqm,
            'price_per_hour': self.price_per_hour,
            'price_per_day': self.price_per_day,
            'amenities': self.amenities or [],
            'phone_primary': self.phone_primary,
            'phone_secondary': self.phone_secondary,
            'whatsapp_number': self.whatsapp_number,
            'email': self.email,
            'is_active': self.is_active,
            'is_verified': self.is_verified,
            'average_rating': self.average_rating,
            'total_reviews': self.total_reviews,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'images': [img.to_dict() for img in self.images],
            'owner_id': self.owner_id
        }

class VenueImage(db.Model):
    __tablename__ = 'venue_images'
    
    id = db.Column(db.Integer, primary_key=True)
    venue_id = db.Column(db.Integer, db.ForeignKey('venues.id'), nullable=False)
    image_url = db.Column(db.String(500), nullable=False)
    image_type = db.Column(db.String(50))  # 'main', 'gallery', 'floor_plan'
    caption_en = db.Column(db.String(200))
    caption_ar = db.Column(db.String(200))
    display_order = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self, language='en'):
        caption = self.caption_en if language == 'en' else self.caption_ar
        return {
            'id': self.id,
            'image_url': self.image_url,
            'image_type': self.image_type,
            'caption': caption,
            'display_order': self.display_order
        }

class EventType(db.Model):
    __tablename__ = 'event_types'
    
    id = db.Column(db.Integer, primary_key=True)
    name_en = db.Column(db.String(100), nullable=False)
    name_ar = db.Column(db.String(100), nullable=False)
    icon = db.Column(db.String(100))
    is_active = db.Column(db.Boolean, default=True)
    
    def to_dict(self, language='en'):
        name = self.name_en if language == 'en' else self.name_ar
        return {
            'id': self.id,
            'name': name,
            'icon': self.icon,
            'is_active': self.is_active
        }

