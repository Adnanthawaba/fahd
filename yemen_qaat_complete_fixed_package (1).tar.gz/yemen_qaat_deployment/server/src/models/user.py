from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from enum import Enum

db = SQLAlchemy()

class UserRole(Enum):
    CUSTOMER = "customer"
    VENUE_OWNER = "venue_owner"
    ADMIN = "admin"

class User(db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    
    # Basic information
    first_name_en = db.Column(db.String(100), nullable=False)
    first_name_ar = db.Column(db.String(100))
    last_name_en = db.Column(db.String(100), nullable=False)
    last_name_ar = db.Column(db.String(100))
    
    # Contact information
    email = db.Column(db.String(120), unique=True, nullable=False)
    phone_number = db.Column(db.String(20), unique=True, nullable=False)
    whatsapp_number = db.Column(db.String(20))
    
    # Authentication
    password_hash = db.Column(db.String(255), nullable=False)
    is_phone_verified = db.Column(db.Boolean, default=False)
    is_email_verified = db.Column(db.Boolean, default=False)
    
    # User role and status
    role = db.Column(db.Enum(UserRole), default=UserRole.CUSTOMER)
    is_active = db.Column(db.Boolean, default=True)
    
    # Profile information
    profile_image_url = db.Column(db.String(500))
    date_of_birth = db.Column(db.Date)
    gender = db.Column(db.String(10))
    
    # Location
    city_en = db.Column(db.String(100))
    city_ar = db.Column(db.String(100))
    governorate_en = db.Column(db.String(100))
    governorate_ar = db.Column(db.String(100))
    
    # Preferences
    preferred_language = db.Column(db.String(5), default='ar')  # 'ar' or 'en'
    notification_preferences = db.Column(db.JSON)
    
    # Business information (for venue owners)
    business_name_en = db.Column(db.String(200))
    business_name_ar = db.Column(db.String(200))
    business_license = db.Column(db.String(100))
    business_address_en = db.Column(db.String(500))
    business_address_ar = db.Column(db.String(500))
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_login = db.Column(db.DateTime)
    
    def __repr__(self):
        return f'<User {self.email}>'

    def to_dict(self, language='en'):
        first_name = self.first_name_en if language == 'en' else (self.first_name_ar or self.first_name_en)
        last_name = self.last_name_en if language == 'en' else (self.last_name_ar or self.last_name_en)
        city = self.city_en if language == 'en' else (self.city_ar or self.city_en)
        governorate = self.governorate_en if language == 'en' else (self.governorate_ar or self.governorate_en)
        business_name = self.business_name_en if language == 'en' else (self.business_name_ar or self.business_name_en)
        business_address = self.business_address_en if language == 'en' else (self.business_address_ar or self.business_address_en)
        
        return {
            'id': self.id,
            'first_name': first_name,
            'last_name': last_name,
            'full_name': f"{first_name} {last_name}",
            'email': self.email,
            'phone_number': self.phone_number,
            'whatsapp_number': self.whatsapp_number,
            'role': self.role.value if self.role else None,
            'is_active': self.is_active,
            'is_phone_verified': self.is_phone_verified,
            'is_email_verified': self.is_email_verified,
            'profile_image_url': self.profile_image_url,
            'date_of_birth': self.date_of_birth.isoformat() if self.date_of_birth else None,
            'gender': self.gender,
            'city': city,
            'governorate': governorate,
            'preferred_language': self.preferred_language,
            'business_name': business_name,
            'business_address': business_address,
            'business_license': self.business_license,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'last_login': self.last_login.isoformat() if self.last_login else None
        }
    
    def is_venue_owner(self):
        return self.role == UserRole.VENUE_OWNER
    
    def is_admin(self):
        return self.role == UserRole.ADMIN
